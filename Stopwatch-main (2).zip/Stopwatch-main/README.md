# stopwatch
Stopwatch frontend project for Coding Ninja skill test.
This project is given by Coding Ninjas

